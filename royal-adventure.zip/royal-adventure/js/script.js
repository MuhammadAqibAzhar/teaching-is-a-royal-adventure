// Home Banner Slider
$('.cusHomeBanSlider').slick({
	slidesToShow: 1,
	dots: false,
	arrows: true,
    autoplay: true,
    autoplaySpeed: 1300,
    fade: true,
    prevArrow: '<i class="fal fa-long-arrow-left"></i>',
	nextArrow: '<i class="fal fa-long-arrow-right"></i>'
});

// teaching Page Sider

$('.teachCustomerSlider').slick({
	slidesToShow: 1,
	dots: false,
	arrows: true,
    autoplay: true,
    autoplaySpeed: 1300,
    prevArrow: '<i class="far fa-angle-left"></i>',
	nextArrow: '<i class="far fa-angle-right"></i>'
});

// Product Detail Page Thumbnail slider

$('.slider-content').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  fade: false,
	infinite: true,
	speed: 400,
  asNavFor: '.slider-thumb',
    arrows: true,
    prevArrow: '<i class="fal fa-long-arrow-left"></i>',
    nextArrow: '<i class="fal fa-long-arrow-right"></i>',
    responsive: [
      
      {
        breakpoint: 480,
        settings: {
          autoplay: true,
          autoplaySpeed: 2000,
        }
      }
    ]
});
$('.slider-thumb').slick({
  // rows:2,
  slidesToShow: 4,
  slidesToScroll: 4,
  asNavFor: '.slider-content',
  dots: false,
  arrows: false,
  centerMode: false,
  focusOnSelect: true
});

// Quantity increaser and decreaser function

$(document).ready(function() {
  $('.minus').click(function () {
      var $input = $(this).parent().find('input');
      var count = parseInt($input.val()) - 1;
      count = count < 1 ? 1 : count;
      $input.val(count);
      $input.change();
      return false;
  });
  $('.plus').click(function () {
      var $input = $(this).parent().find('input');
      $input.val(parseInt($input.val()) + 1);
      $input.change();
      return false;
  });
});

// log in form password see hide function

function myFunction() {
    var x = document.getElementById("myInput");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  };
  
  function myFunction1() {
   var y = document.getElementById("mySHow");
     y.classList.toggle("changelogo");
  };

  // sign up form password see hide function

  function myFunction2() {
    var a = document.getElementById("myInput1");
    if (a.type === "password") {
      a.type = "text";
    } else {
      a.type = "password";
    }
  };
  
  function myFunction3() {
   var b = document.getElementById("mySHow1");
     b.classList.toggle("changelogo");
  };

// select option Filters

  $(document).ready(function(event){
    $('.sortFilter').change(function(){
      $this = $(this);
      $('.curriProductBox').hide();
      $('.'+$this.val()).show();
      console.log("showing "+$this.val()+" boxes");
     });
  });

    // Navbar button function

    $('button.mobNavController').click(function(){
      $(this).toggleClass('activate-nav');
      $(this).parent().siblings('.SiteHederMenu').toggleClass('nav-active');
    })

// product detail page footer margin Bottom

$(document).ready(function(){

if($(window).width() < 767 ) {
    if ($("body").hasClass("marBtm")) {
      $("footer").css('margin-bottom' , '105px');
    } else {
      $("footer").css('margin-bottom' , '0px');
    }
}

});

  // Tabbing function

  function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
  }
  document.getElementById("defaultOpen").click();


